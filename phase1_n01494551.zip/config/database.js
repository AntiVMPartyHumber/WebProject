module.exports = {
    url : "mongodb+srv://admin:admin@cluster0.r6pssxj.mongodb.net/sample_restaurants" //Andreas Atlas
};